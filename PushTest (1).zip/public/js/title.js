const SITE_TITLE = "송파푸드마켓";

document.title = SITE_TITLE;
document.getElementById("top-title").innerHTML = SITE_TITLE;